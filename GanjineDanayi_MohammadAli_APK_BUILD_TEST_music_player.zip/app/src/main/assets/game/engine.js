window.GDMEngine = (() => {
  const KEY='gdm_progress';
  const defaults=()=>({unlocked:1,completed:{},stars:0,history:[],skills:{},recent:[]});
  function load(){try{return Object.assign(defaults(),JSON.parse(localStorage.getItem(KEY)||'{}'))}catch(e){return defaults()}}
  function save(s){localStorage.setItem(KEY,JSON.stringify(s));return s}
  function mastery(s,skill){const x=s.skills[skill];if(!x)return 0;const n=(x.r||0)+(x.n||0);return n?Math.round(100*x.r/n):0}
  function difficultyFor(s,skill){const m=mastery(s,skill);return m>=90?4:m>=70?3:m>=40?2:1}
  function registerAnswer(s,q,ok){const x=s.skills[q.skill]||{r:0,n:0};ok?x.r++:x.n++;x.last=Date.now();s.skills[q.skill]=x;s.recent=(s.recent||[]).concat(q.id).slice(-40);return s}
  function reward(score){return score>=18?3:score>=14?2:score>=10?1:0}
  function remedial(q){return {skill:q.skill,source_id:q.source_id,steps:['آموزش کوتاه','یک مثال ساده','یک سؤال آسان','یک سؤال مشابه','یک سؤال انتقالی','بازگشت به مسیر اصلی']}}
  return {load,save,mastery,difficultyFor,registerAnswer,reward,remedial};
})();
